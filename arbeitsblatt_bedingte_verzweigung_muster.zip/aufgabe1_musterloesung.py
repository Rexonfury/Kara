if not kara.treeFront():
    kara.move()