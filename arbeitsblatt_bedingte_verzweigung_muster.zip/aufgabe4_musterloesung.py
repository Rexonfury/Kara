if kara.treeFront() and kara.treeLeft() and kara.treeRight(): 
    kara.turnLeft()
    kara.turnLeft()
else:    
    kara.move()    