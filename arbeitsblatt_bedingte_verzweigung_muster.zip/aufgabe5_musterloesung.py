# BEFEHLE:  kara.
#   move()  turnRight()  turnLeft()
#   putLeaf()  removeLeaf()
#
# SENSOREN: kara.
#   treeFront()  treeLeft()  treeRight()
#   mushroomFront()  onLeaf()
#
if kara.onLeaf():
    kara.removeLeaf()
if not kara.treeLeft():
    kara.turnLeft()
if kara.treeFront():
    kara.turnRight()
else:
    kara.move()
    
    
    